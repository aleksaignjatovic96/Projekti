﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Security.Principal;
using System.Threading;

namespace ClientApp
{
	public class Program
	{
		static void Main(string[] args)
		{
			NetTcpBinding binding = new NetTcpBinding();
			string address = "net.tcp://localhost:9999/WCFService";
            binding.Security.Mode = SecurityMode.Transport;
            binding.Security.Transport.ProtectionLevel =
            System.Net.Security.ProtectionLevel.EncryptAndSign;

            binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Windows;

            using (WCFClient proxy = new WCFClient(binding, new EndpointAddress(new Uri(address))))
			{
                //TO ASK,how to disable ntlm
               // (Thread.CurrentPrincipal.Identity as WindowsIdentity).
				proxy.Read();
				proxy.ExecuteCommand();
				proxy.EditSystemConfiguration();
				proxy.ManageNetworkModel();
                proxy.CreateFile();
                Console.WriteLine(WindowsIdentity.GetCurrent().Name);
            }

			Console.ReadLine();
		}
	}
}
