﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Contracts;

namespace ClientApp
{
	public class WCFClient : ChannelFactory<IWCFService>, IWCFService, IDisposable
	{
		IWCFService factory;

		public WCFClient(NetTcpBinding binding, EndpointAddress address)
			: base(binding, address)
		{
            this.Credentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
            //this.Credentials.Windows.AllowNtlm = false;
			factory = this.CreateChannel();
		}

		#region Read()
		
		public void Read()
		{
			try
			{
				factory.Read();
				Console.WriteLine("Read() allowed.");
			}
			catch (Exception e)
			{
				Console.WriteLine("Error while trying to Read(). {0}", e.Message);
			}
		}

		#endregion

		#region ExecuteCommand()
		
		public void ExecuteCommand()
		{
			
			try
			{
				factory.ExecuteCommand();
				Console.WriteLine("ExecuteCommand allowed.");
			}
			catch (Exception e)
			{
				Console.WriteLine("Error while trying to ExecuteCommand(). {0}", e.Message);
			}
		}

		#endregion		

		#region ManageNetworkModel()
		
		public void ManageNetworkModel()
		{
			try
			{
				factory.ManageNetworkModel();
				Console.WriteLine("ManageNetworkModel() allowed.");
			}
			catch (Exception e)
			{
				Console.WriteLine("Error while trying to ManageNetworkModel(). {0}", e.Message);
			}
		}

		#endregion

		#region EditSystemConfiguration

		public void EditSystemConfiguration()
		{
			try
			{
				factory.EditSystemConfiguration();
				Console.WriteLine("EditConfiguration() allowed.");
			}
			catch (Exception e)
			{
				Console.WriteLine("Error while trying to EditConfiguration(). {0}", e.Message);
			}
		}

		#endregion



		public void Dispose()
		{
			if (factory != null)
			{
				factory = null;
			}

			this.Close();
		}

        public void CreateFile()
        {
            factory.CreateFile();
        }
    }
}
