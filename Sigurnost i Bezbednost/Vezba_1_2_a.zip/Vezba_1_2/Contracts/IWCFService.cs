﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Contracts
{
	[ServiceContract]
	public interface IWCFService
	{
		[OperationContract]
		void Read();

		[OperationContract]
		void ExecuteCommand();

		[OperationContract]
		void ManageNetworkModel();

		[OperationContract]
		void EditSystemConfiguration();

        [OperationContract]
        void CreateFile();
	}
}
