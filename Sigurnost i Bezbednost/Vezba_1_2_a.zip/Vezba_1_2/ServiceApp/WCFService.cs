﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Contracts;
using System.Security.Principal;
using System.Threading;
using System.IO;
using System.ServiceModel;

namespace ServiceApp
{
    public class WCFService : IWCFService
	{
        public void Read()
        {
            Console.WriteLine("Read() successfully executed.");
            Console.WriteLine(Thread.CurrentPrincipal.Identity.Name + " " + Thread.CurrentPrincipal.Identity.AuthenticationType);

        }
		public void ExecuteCommand()
		{
			Console.WriteLine("ExecuteCommand() successfully executed.");
		}		

		public void ManageNetworkModel()
		{
			Console.WriteLine("ManageNetworkModel() successfully executed.");
		}

		public void EditSystemConfiguration()
		{
			Console.WriteLine("EditConfiguration() successfully executed.");
		}

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void CreateFile()
        {
            Console.WriteLine($"Service security context: {ServiceSecurityContext.Current.WindowsIdentity.Name}");
            Console.WriteLine(WindowsIdentity.GetCurrent().Name);
            //using (ServiceSecurityContext.Current.WindowsIdentity.Impersonate())
            //{                 //moze oba
            //using((Thread.CurrentPrincipal.Identity as WindowsIdentity).Impersonate())
                Console.WriteLine(WindowsIdentity.GetCurrent().Name);
                Console.WriteLine(Thread.CurrentPrincipal.Identity.Name);
                if (!File.Exists(@"C:\Users\Administrator\Desktop\Vezba_1_2\Storage\ttt.txt"))
                {
                    using (File.Create(@"C:\Users\Administrator\Desktop\Vezba_1_2\Storage\ttt.txt"))
                    {
                        Console.WriteLine("File created.");
                    }
                    File.Delete(@"C:\Users\Administrator\Desktop\Vezba_1_2\Storage\ttt.txt");
                }
            //}
        }
    }
}
