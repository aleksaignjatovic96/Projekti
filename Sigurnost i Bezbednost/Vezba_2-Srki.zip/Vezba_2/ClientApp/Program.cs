﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Text;
using System.ServiceModel;

namespace ClientApp
{
	public class Program
	{
		static void Main(string[] args)
		{
			NetTcpBinding binding = new NetTcpBinding();

		    binding.Security.Mode = SecurityMode.Transport;
		    binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Windows;
		    binding.Security.Transport.ProtectionLevel = ProtectionLevel.EncryptAndSign;

			string address = "net.tcp://localhost:9999/WCFService";

			using (WCFClient proxy = new WCFClient(binding, new EndpointAddress(new Uri(address))))
			{
				proxy.Read();
			    proxy.Modify(10);
                proxy.Delete();
			}

			Console.ReadLine();
		}
	}
}
