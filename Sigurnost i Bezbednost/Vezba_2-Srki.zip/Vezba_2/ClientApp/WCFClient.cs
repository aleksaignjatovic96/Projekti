﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Threading;
using Contracts;

namespace ClientApp
{
	public class WCFClient : ChannelFactory<IWCFService>, IWCFService, IDisposable
	{
		IWCFService factory;

		public WCFClient(NetTcpBinding binding, EndpointAddress address)
			: base(binding, address)
		{
			factory = this.CreateChannel();
		}

		#region Read()
		
		public int Read()
		{
		    int retVal = -1;

			try
			{
			    retVal = factory.Read();
				Console.WriteLine("Read() allowed.");
			}
			catch (Exception e)
			{
				Console.WriteLine("Error while trying to Read(). {0}", e.Message);
			}

		    return retVal;
		}

		#endregion

		#region Modify()
		
		public int Modify(int newValue)
		{
		    int retVal = -1;

			try
			{
				retVal = factory.Modify(newValue);
				Console.WriteLine("Modify allowed.");
			}
			catch (Exception e)
			{
				Console.WriteLine("Error while trying to modify(). {0}", e.Message);
			}

		    return retVal;
		}

		#endregion		

		#region Delete()
		
		public void Delete()
		{
			try
			{
				factory.Delete();
				Console.WriteLine("Delete() allowed.");
			}
			catch (Exception e)
			{
				Console.WriteLine("Error while trying to delete(). {0}", e.Message);
			}
		}

		#endregion

		public void Dispose()
		{
			if (factory != null)
			{
				factory = null;
			}

			this.Close();
		}
	}
}
