﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Contracts
{
	[ServiceContract]
	public interface IWCFService
	{
		[OperationContract]
		int Read();

		[OperationContract]
		int Modify(int newValue);

		[OperationContract]
		void Delete();	
	}
}
