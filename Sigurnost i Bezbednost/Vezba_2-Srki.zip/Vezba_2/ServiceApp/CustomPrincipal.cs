﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Security.Principal;
using System.Text;
using ServiceApp.RBAC;

namespace ServiceApp
{
    public class CustomPrincipal : IPrincipal
    {
        private WindowsIdentity myIdentity;
        private HashSet<Permission> myPermissions = new HashSet<Permission>();
        public CustomPrincipal(IIdentity identity)
        {
            myIdentity = identity as WindowsIdentity;

            for (int i = 0; i < myIdentity.Groups.Count; i++)
            {
                var permissionsForGroup = RBACService.GetPermissions(myIdentity.Groups[i].Value);
                for (int j = 0; j < permissionsForGroup.Count; j++)
                {
                    myPermissions.Add(permissionsForGroup[j]);
                }
            }
        }

        public bool IsInRole(string role)
        {
            Permission permissionEnum;
            if (Permission.TryParse(role, true, out permissionEnum))
            {
                return myPermissions.Contains(permissionEnum);
            }
            else
            {
                return false;
            }
        }

        public IIdentity Identity => myIdentity;
    }
}
