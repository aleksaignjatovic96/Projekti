﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceApp.RBAC;

namespace ServiceApp
{
    [Serializable]
    public class Group
    {
        public Group()
        {
                
        }

        public Group(string name)
        {
            this.name = name;
        }
        public string name { get; set; }
        public List<Permission> Permissions { get; set; }      
    }
}
