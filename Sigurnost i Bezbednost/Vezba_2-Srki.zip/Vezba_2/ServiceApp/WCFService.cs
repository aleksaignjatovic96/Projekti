﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using Contracts;

namespace ServiceApp
{
    //[PrincipalPermission(SecurityAction.Demand, Authenticated = true, Role = "reader")]
	public class WCFService : IWCFService
	{
	    private const int InitialValue = 0;
	    private static int _currentValue = InitialValue;

        public int Read()
		{
			Console.WriteLine("Read() successfully executed.");
		    return _currentValue;
		}

        [PrincipalPermission(SecurityAction.Demand, Authenticated = true, Role = "Modify")]
        public int Modify(int newValue)
		{
			Console.WriteLine("Modify() successfully executed.");
		    return _currentValue = newValue;
		}

        [PrincipalPermission(SecurityAction.Demand, Authenticated = true, Role = "Delete")]
        [PrincipalPermission(SecurityAction.Demand, Authenticated = true, Role = "Modify")]
        public void Delete()
		{
			Console.WriteLine("Delete() successfully executed.");
		    _currentValue = InitialValue;
		}

	}
}
